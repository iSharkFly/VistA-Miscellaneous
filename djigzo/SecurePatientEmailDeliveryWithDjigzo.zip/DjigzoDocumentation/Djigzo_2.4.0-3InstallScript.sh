#!/bin/bash
aptitude install sudo postgresql postfix openjdk-6-jre openjdk-6-jre-headless tzdata-java ant ant-optional mktemp wget libsasl2-modules
wget http://djigzo.com/downloads/djigzo-release-2.4.0-3/djigzo_2.4.0-3_all.deb
wget http://djigzo.com/downloads/djigzo-release-2.4.0-3/djigzo-web_2.4.0-3_all.deb
dpkg -i djigzo_2.4.0-3_all.deb
dpkg -i djigzo-web_2.4.0-3_all.deb
cp /etc/postfix/djigzo-main.cf /etc/postfix/main.cf
cp /etc/postfix/djigzo-master.cf /etc/postfix/master.cf
newaliases #rebuilds sendmails alias file
/etc/init.d/postfix restart
aptitude install tomcat6
bash -c 'echo "JAVA_OPTS=\"\$JAVA_OPTS -Ddjigzo-web.home=/usr/share/djigzo-web\"" >> /etc/default/tomcat6'
bash -c 'echo "JAVA_OPTS=\"\$JAVA_OPTS -Djava.awt.headless=true -Xmx256M\"" >> /etc/default/tomcat6'
bash -c 'echo "TOMCAT6_SECURITY=no" >> /etc/default/tomcat6'
chown tomcat6:djigzo /usr/share/djigzo-web/ssl/sslCertificate.p12
cp /usr/share/djigzo-web/conf/tomcat/server-T6.xml /etc/tomcat6/server.xml
bash -c 'echo "<Context docBase=\"/usr/share/djigzo-web/djigzo.war\" unpackWAR=\"false\"/>" > /etc/tomcat6/Catalina/localhost/djigzo.xml'
/etc/init.d/tomcat6 restart

Extensive documentation for the latest Djigzo version can be found on Djigzo.com but the
version from 10-2012 is included here for alternate reference.

If you choose to start with the Djigzo virtual appliance, you can run it on Virtual Box
by using just the hard disk file, Create a new 32-bits Ubuntu virtual machine and use the
.vmdk disk image. See Virtual Appliance guide for more info.


For Meaningful Use certification, Djigzo was installed on its own virtual machine from scratch
and then configured as you can find in the sample file and Dovecot Mail server used to store mail
for pickup by the "patients" who had to import the certificate that was created in Djigzo and
sent to patients to pick up their mail containing encrypted CCRs and a style sheet to display
the CCR.
